"""Source code"""

__author__ = """Jozsef Venczeli"""
__email__ = "venczeli.jozsef@gmail.com"
__version__ = "0.1.0"
